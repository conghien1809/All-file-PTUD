@extends('admin_layout')
@section('admin_content')
<h3>Đăng nhập thành công vào trang Admin</h3>

@endsection